51 path=plugins/owner-listbanned-(pending 🟡).js
